import UIKit

struct Group {
    
    let groupName: String
    let groupAvatar: UIImage?
    
}
